
li=["clubs","spades","diamonds","hearts","joker"]

s='''
{
	"credit": "Made with Blockbench",
	"textures": {
		"0": "clover_deck/1",
		"1": "clover_deck/back",
		"particle": "clover_deck/1"
	},
	"elements": [
		{
			"from": [0, 0, 0],
			"to": [9, 16, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [23, 8, 8]},
			"faces": {
				"north": {"uv": [0, 0, 8, 12], "texture": "#1"},
				"south": {"uv": [0, 0, 8, 12], "texture": "#0"}
			}
		},
		{
			"from": [0, 0.5, 0],
			"to": [0.25, 15.5, 0.2],
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [8.75, 0.5, 0],
			"to": [9, 15.5, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [16.75, 8, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [8.5, 0.25, 0],
			"to": [8.75, 0.75, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [16.5, 7.75, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [8.5, 15.25, 0],
			"to": [8.75, 15.75, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [16.5, 23, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [0.25, 15.25, 0],
			"to": [0.5, 15.75, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [8.25, 23, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [0.25, 0.25, 0],
			"to": [0.5, 0.75, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [8.25, 7.75, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [0.5, 0.25, 0],
			"to": [8.5, 0.5, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [8.5, 7.5, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		},
		{
			"from": [0.5, 15.5, 0],
			"to": [8.5, 15.75, 0.2],
			"rotation": {"angle": 0, "axis": "y", "origin": [8.5, 23.25, 8]},
			"faces": {
				"north": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"east": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"south": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"west": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"up": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"},
				"down": {"uv": [1, 11, 1.25, 11.25], "texture": "#1"}
			}
		}
	],
	"display": {
		"thirdperson_righthand": {
			"translation": [0, 2.25, 2.5],
			"scale": [0.3, 0.3, 0.3]
		},
		"thirdperson_lefthand": {
			"translation": [-2, 2.25, 2.5],
			"scale": [0.3, 0.3, 0.3]
		},
		"firstperson_righthand": {
			"translation": [6.75, 0, 0]
		},
		"firstperson_lefthand": {
			"translation": [6.75, 0, 0]
		},
		"head": {
			"rotation": [0, -180, 0],
			"translation": [-10, -40, -26],
			"scale": [3, 3, 3]
		}
	}
}
'''
s1='"0": "clover_deck/1"'
s2='"particle": "clover_deck/1"'

cnt=0
for prefix in li:
	for card_num in range(1,13+1):
		if cnt>=54:
			break

		cnt+=1
		ss=s.replace(s1,'"0": "clover_deck/{}"'.format(cnt),1).replace(s2,'"particle": "clover_deck/{}"'.format(cnt),1)

		with open("./doudizhu/"+prefix+str(card_num)+".json","w") as f:
			f.write(ss)
		