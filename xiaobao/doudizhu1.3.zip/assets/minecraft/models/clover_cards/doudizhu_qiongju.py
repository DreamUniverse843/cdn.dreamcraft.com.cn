f=open("doudizhu.txt","w")

def liandui(b,length):
    ss="execute if score card_cnt outcards matches {}".format(length*2)
    for i in range(b,b+length):
        if i==14:
            s=" if score {} outcards matches 2".format(1)
        else:
            s=" if score {} outcards matches 2".format(i)
        ss+=s
    if b+length-1==14:
        s=" run scoreboard players set max_card outcards {}".format(1)
    else:
        s=" run scoreboard players set max_card outcards {}".format(b+length-1)
    ss+=s
    #print(ss)
    f.write(ss+'\n')

def shunzi(b,length):
    ss="execute if score card_cnt outcards matches {}".format(length)
    for i in range(b,b+length):
        if i==14:
            s=" if score {} outcards matches 1".format(1)
        else:
            s=" if score {} outcards matches 1".format(i)
        ss+=s
    if b+length-1==14:
        s=" run scoreboard players set max_card outcards {}".format(1)
    else:
        s=" run scoreboard players set max_card outcards {}".format(b+length-1)
    ss+=s
    #print(ss)
    f.write(ss+'\n')  

def feiji_without_wings(b,length):
    ss="execute if score card_cnt outcards matches {}".format(length*3)
    for i in range(b,b+length):
        if i==14:
            s=" if score {} outcards matches 3".format(1)
        else:
            s=" if score {} outcards matches 3".format(i)
        ss+=s
    if b+length-1==14:
        s=" run scoreboard players set max_card outcards {}".format(1)
    else:
        s=" run scoreboard players set max_card outcards {}".format(b+length-1)
    ss+=s
    #print(ss)
    f.write(ss+'\n')

if __name__=='__main__':
    #记得最后把14替换成1
    '''
    for len in range(3,12+1):
        for b in range(3,15-len+1): #不考虑A:14-len+1，考虑A：15-len+1
            liandui(b,len)
    
    for len in range(5,12+1):
        for b in range(3,15-len+1): #不考虑A:14-len+1，考虑A：15-len+1
            shunzi(b,len)
    '''
    for len in range(2,12+1):
        for b in range(3,15-len+1): #不考虑A:14-len+1，考虑A：15-len+1
            feiji_without_wings(b,len)
    